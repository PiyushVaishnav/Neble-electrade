<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
  
if($_POST)
{
    
   
    $Email = $_POST['Email'];
    $Phone = $_POST['txtPhone'];
    $mymsg = $_POST['txtMessg'];
            
    require './PHPMailerAutoload.php';


            $mail = new PHPMailer;

            $mail->isSMTP();                                // Set mailer to use SMTP
                                                 
            
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->Port = 587;                                    // TCP port to connect to
            $mail->Username = 'nobleelectrade1@gmail.com';                 // SMTP username
            $mail->Password = 'noble@123';                           // SMTP password
            
            $mail->addReplyTo('nobleelectrade1@gmail.com', 'nobleelectrade');
            
            $mail->setFrom('nobleelectrade1@gmail.com', 'nobleelectrade');
            
            $mail->addReplyTo('nobleelectrade1@gmail.com', 'nobleelectrade');
            
          
            $mail->addAddress('nobleelectrade1@gmail.com', 'nobleelectrade');     // Add a recipient

            
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = "$mysubject";  
            
            $body = "Hello.. <br> I'm $myname. <br> Email ID :: $myemail <br><br> Message :: <br> .$mymsg ";
            $mail->msgHTML($body);
            

            if(!$mail->send()) {
                echo "<script> alert ('Messasge could not be sent.');</script>";
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
                echo "<script> alert ('Your Message sent.');window.location='index.php';</script>";
            }
}
?>

<html>
    <head>
        <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
                $(".memenu").memenu();
            });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
            $(function () {
                $("#slider").responsiveSlides({
                    auto: true,
                    speed: 500,
                    namespace: "callbacks",
                    pager: true,
                });
            });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
        <!--content-->

        <div class="contact">
            <div class="container">
                <h1>Contact</h1>

                <div class="contact-grids">
                    <div class="contact-form">
                        <form>
                            <div class="col-md-6  register-top-grid">

                                <div class="mation">
                                    <span>Email</span>
                                    <input type="text" name="Email" required="true"> 
                                </div>
                            </div>
                            <div class=" col-md-6 register-bottom-grid">
                                <div class="mation">
                                    <span>Phonenumber</span>
                                    <input type="text" name="txtPhone" required="true">
                                </div>
                            </div>		
                            <div class="contact-bottom-top">
                                <span>Message</span>
                                <textarea name="txtmassg" > </textarea>								
                            </div>
                            <input type="submit" value="Send">
                        </form>
                    </div>
                    <div class="address">
                        <div class=" address-more">
                            <h2>Address</h2>
                            <div class="col-md-4 address-grid">
                                <i class="glyphicon glyphicon-map-marker"></i>
                                <div class="address1">
                                    <p>Rajkot-360001</p>
                                    <p>Gujarat, India</p>
                                    
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="col-md-4 address-grid ">
                                <i class="glyphicon glyphicon-phone"></i>
                                <div class="address1">
                                    <p>+0281 2464749</p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="col-md-4 address-grid ">
                                <i class="glyphicon glyphicon-envelope"></i>
                                <div class="address1">
                                    <p>nobleelectrade1</p>
                                    <p>@Gmail.com</p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>







        <!--//content-->
        <!--footer-->
        <?php
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>