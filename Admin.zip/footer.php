<div class="footer">
<!--            <div class="container">
                <div class="footer-top">
                    <div class="col-md-8 top-footer">
                        <iframe src="https://www.google.co.in/maps/@23.0746742,72.5263983,15z?hl=en" allowfullscreen=""></iframe>
                    </div>
                    <div class="col-md-4 top-footer1">
                        <h2>Newsletter</h2>
                        <form>
                            <input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {
                                                            this.value = '';}">
                            <input type="submit" value="SUBSCRIBE">
                        </form>
                    </div>
                    <div class="clearfix"> </div>	
                </div>	
            </div>-->
            <div class="footer-bottom">
                <div class="container">
                    <div class="col-sm-3 footer-bottom-cate">
                        
                    </div>
                    <div class="col-sm-3 footer-bottom-cate">
                        <h6>Categories</h6>
                        <ul>
                                                     <?php
                                                  $selectq = mysql_query("select *from category ") or die(mysql_error());                     
                                                    //echo "<select name='txtcatid'>";

                                                    while ($data = mysql_fetch_row($selectq)) 
                                                            {
                                                               echo "<li><a href='index.php?cid=$data[0]' value='{$data[0]}'>$data[1]</a></li>";
                                                            }

                                                    //echo "</select>";
                                                  ?>     

                                                </ul>	
                    </div>
                    <div class="col-sm-3 footer-bottom-cate">
                        
                    </div>
                    <div class="col-sm-3 footer-bottom-cate cate-bottom">
                        <h6>Our Address</h6>
                        <ul>
                            <li>3rd Floor </li>
                            <li>Opp. Dr. Dayabhai Clinic</li>
                            <li>2, Bhaktinagar Station Road</li>
                            <li>Rajkot-360001</li>
                            <li>Gujarat, India</li>
                            <li class="phone">PH :0281 2464749</li>
                        </ul>
                    </div>
                    <div class="clearfix"> </div>
                    <p class="footer-class"> © 2017 Noble Eleatic. All Rights Reserved | Design by <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank">Piyush Vaishnav</a> </p>
                </div>
            </div>
        </div>