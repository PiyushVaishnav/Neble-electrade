
<?php
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());

if ($_POST) {
    $Name = $_POST['txtname'];
    $Email = $_POST['txtemail'];
    $Password = $_POST['txtpassword'];
    $Address = $_POST['txtaddress'];
    $Mobile = $_POST['txtmobile'];


    $q = mysql_query("insert into user(Name,Email,Password,Address,Mobile)values('{$Name}','{$Email}','{$Password}','{$Address}','{$Mobile}')") or die(mysql_error());

    if ($q) {

        echo"<script> alert('Registration successful');</script>";
    }
}
?>


<html>
    <head>
        <title>Noble Electrade</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
        <!--content-->
       
        
        
         <div class="account">
            <div class="container">
                <h1>Register</h1>
                <div class="account_grid">
                    <div class="col-md-6 login-right">
                        <form method="Post">

                            <span>Name</span>
                            <input type="text" name="txtname" required="true"> 

                            <span>Email</span>
                            <input type="email" name="txtemail" required="true"> 
                            <span>Password</span>
                            <input type="password" name="txtpassword" required="true"> 
                            <span>Address</span>
                            <input type="text" name="txtaddress" required="true"> 
                            <span>Mobile</span>
                            <input type="number" name="txtmobile" required="true"> 
                            
                            <div class="word-in">
                               
                                <input type="submit" value="Submit">
                            </div>
                        </form>
                    </div>	
                    <div class="col-md-6 login-left">
                        <h4>NEW CUSTOMERS</h4>
                        <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                    
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
           
        
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>