<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());


if(isset($_GET['delete']))
{
    
    $delete = $_GET['delete'];
    
    unset($_SESSION['cart'][$delete]);
    
}


echo "<table border='1'>";

echo "<tr>";

echo "<th>ID</th>";
echo "<th>Name</th>";
echo "<th>Price</th>";
echo "<th>Image</th>";

echo "<th>Action</th>";
echo "<tr>";


$sum = array();
if(isset($_SESSION['cart']) && !empty($_SESSION['cart']))
{

    $i = 0;
    foreach ($_SESSION['cart'] as $key => $value) {

        $productq  = mysql_query("select * from  product where Product_id = '{$value}'") or die(mysql_error());
       
        $pdata = mysql_fetch_row($productq);
        
        $i++;
        echo "<td>$i</td>";
        echo "<td>$pdata[1]</td>";
        echo "<td><img src='images/$pdata[5]' style='width:50px;'></td>";
      
        echo "<td>$pdata[4]</td>";
       echo "<td><a href='?delete=$key'>Delete</a></td>";
       
        echo "</tr>";
        
        
        $sum[] = $pdata[4];
        
    }
    
    $totalsum = array_sum($sum);
    echo "<tr>";
    echo "<td>Sum is </td>";
    echo "<td></td>"; echo "<td></td>";
    echo "<td>$totalsum </td>";
    echo "<tr>";

}
 else {

     echo "Cart is Empty";
}

echo "<a href='index.php'>Buy</a>";
echo "</table>";
