<html>
    <head>
        <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
        <!--content-->
       
     <div class="contact">
			<div class="container">
				<h1>About us</h1>
                        </div> 
         <div class="col-md-2 in-contact">
									
             <img src="images/NElogo.png" alt="">
         </div>
         <p>In any Industry either small, medium or big, three fields product requires the most that are Civil, Mechanical & Electrical.
         </p>
         
         <p> At the time of Implementation & at the time of running stage; it might be require in bulk Quantities while in running stage it require as maintenance. That's why these three fields are known as evergreen fields. There is continuous improvements in these fields also & day by day you find something new is invented for making work done with ease.
            Electrical is such a field or technology without which now a days no one can imagine living. It’s important in every aspect of life in today’s world.
         </p>
              <p>  Electricity is required as it's now become our daily need or as one can say we are addicted to it. 
         One feels proud to say that by doing trading of industrial electrical goods we try to satisfy our customer & society needs by putting our 100% effort.

        We would like to introduce as ourselves as one of well-known traders in Industrial Electrical Goods in Saurashtra & Kutch region. We are dealing in many well-known products in this category & we also have good numbers of satisfied customers.

        Noble Electrade(Rajkot)pvt.ltd. A leading business house providing world class and cost effective innovative solutions in electrical technology. We are authorized dealers for supply of high quality, low voltage switchgear, motors, and other electrical accessories since last three decades.
</p>

    <p>We associate us with all major global player :- BCH, C&S, EATON - Moeller, Epcos, Minilec, Ngef.

    We are supplier of power distribution panel, motor control & power control panel, automatic power factor control panel with our installation in every industrial sector.
<p>
    We consistently strive for customer satisfaction through our quality products and best services.</p>
        
	</div> 
        
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>