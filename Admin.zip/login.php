<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());

if($_POST)
{
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    
    $q = mysql_query("select  * from user where Email='{$Email}' and Password = '{$Password}'") or die(mysql_error());
    
    $data = mysql_fetch_row($q);
    
    if($data>0)
    {
        $_SESSION['User_id'] = $data[0];
        $_SESSION['Email'] = $Email;
        
        header("location:checkout.php");
    }
    else
    {
        echo "<script>alert('Login Fail');</script>";
    }
}


?>


<html>
    <head>
       <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
      
        <!--content-->
       
        
        
        <div class="account">
            <div class="container">
                <h1>Account</h1>
                <div class="account_grid">
                    <div class="col-md-6 login-right">
                        <form method="Post">

                            <span>Email Address</span>
                            <input type="email" name="Email" required="true"> 

                            <span>Password</span>
                            <input type="password" name="Password" required="true"> 
                            <div c  lass="word-in">
                                <a class="forgot" href="forgetpassword.php">Forgot Your Password ?</a>
                                <input type="submit" value="Login">
                            </div>
                        </form>
                    </div>	
                    <div class="col-md-6 login-left">
                        <h4>NEW CUSTOMERS</h4>
                        <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                        <a class="acount-btn" href="register.php">Create an Account</a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>