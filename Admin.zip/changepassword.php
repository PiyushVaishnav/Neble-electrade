<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());

if(!isset($_SESSION['User_id']))
{
    
   // header("location:index.php");
  
    
}

if($_POST)
{
    
    $opass = $_POST['txtoPassword'];
    $npass = $_POST['txtPassword'];
    $cpass = $_POST['txtcPassword'];
    
    $oldpassq = mysql_query("select Password from user where User_id='{$_SESSION['User_id']}' ") or die(mysql_error());
    $oldpassfromdb = mysql_fetch_row($oldpassq);
 
    if($oldpassfromdb[0] == $opass)
    {
        if($npass == $cpass)
        {
            if($opass == $npass)
            {
                echo "<script>maximum 6 characters('Please Try New Password')</script>";
            }else
            {
                mysql_query("update user set Password ='{$npass}' where User_id='{$_SESSION['User_id']}'") or die(mysql_error());
            
                echo "<script>alert('Password Changed');</script>";
            }
            
        }else
        {
            echo "<script>alert('new and Confirm Password Not Match')</script>";
        }
        
    }else
    {
        echo "<script>maximum 6 characters('Old Password Not Match')</script>";
        
    }
    
}

?>


<html>
    <head>
        <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
       
        <div class="header">
            <div class="header-top">
                <div class="container">
                    <div class="col-sm-4 world">
                        </div>
                    <div class="col-sm-4 logo">
                        <a href=""><img src="images/Untitled-3.png" alt=""></a>	
                    </div>

                    <div class="col-sm-4 header-left">		
                        <p class="log"><a  href="index.php" >Logout</a>
                        <a  href=""  >Change Password</a>
                            
                        <div class="cart box_1">
                          

                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="container">
                <div class="head-top">
                    <div class="col-sm-2 number">
                        <span><i class="glyphicon glyphicon-phone"></i>096 6261 0717</span>
                    </div>
                    <div class="col-sm-8 h_menu4">
                        <ul class="memenu skyblue">
                            <li class=" grid"><a  href="index.php">Home</a></li>	
                            <li class=" grid"><a  href="aboutas.php">About us</a></li>	
                           
                            <li><a  href="#">Category</a>
                                <div class="mepanel">
                                    <div class="row">
                                        <div class="col1">
                                            <div class="h_nav">
                                                <h4>All Product</h4>
                                                <ul>
                                                    <?php
                                                  $selectq = mysql_query("select *from category ") or die(mysql_error());                     
                                                    //echo "<select name='txtcatid'>";

                                                    while ($data = mysql_fetch_row($selectq)) 
                                                            {
                                                               echo "<li><a href='index.php?cid=$data[0]' value='{$data[0]}'>$data[1]</a></li>";
                                                            }

                                                    //echo "</select>";
                                                  ?>     

                                                </ul>	
                                            </div>							
                                        </div>
                                      
                                    </div>
                                </div>
                            </li>
                            
                            <li><a class="color6" href="contact.php">Contact</a></li>
                        </ul> 
                    </div>
                    <div class="col-sm-2 search">		
                        <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i> </a>
                    </div>
                    <div class="clearfix"> </div>
                    <!---pop-up-box---->
                    <script type="text/javascript" src="js/modernizr.custom.min.js"></script>    
                    <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
                    <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
                    <!---//pop-up-box---->
                    <div id="small-dialog" class="mfp-hide">
                        <div class="search-top">
                            <div class="login">
                                <input type="submit" value="">
                                <input type="text" value="Type something..." onfocus="this.value = '';" onblur="if (this.value == '') {
                                                                    this.value = '';
                                                                }">		
                            </div>
                            <p>	Shopping</p>
                        </div>				
                    </div>
                    <script>
                        $(document).ready(function () {
                            $('.popup-with-zoom-anim').magnificPopup({
                                type: 'inline',
                                fixedContentPos: false,
                                fixedBgPos: true,
                                overflowY: 'auto',
                                closeBtnInside: true,
                                preloader: false,
                                midClick: true,
                                removalDelay: 300,
                                mainClass: 'my-mfp-zoom-in'
                            });

                        });
                    </script>			
                    <!---->		
                </div>
            </div>
        </div>
        
        
       
        <!--content-->
       
        
        
     <div class="account">
            <div class="container">
                <h1>Change Password</h1>
                <div class="account_grid">
                    <div class="col-md-6 login-right">
                        <form method="Post">
                            <span>Old Password</span>
                            <input type="password" name="txtoPassword" required="true"> 
                    
                            <span>Create Password</span>
                            <input type="password" name="txtPassword" required="true"> 
                            <span>Confirm Password</span>
                            <input type="password" name="txtcPassword" required="true"> 

                            
                                                <div c  lass="word-in">
                                <input type="submit" value="Send">
                            </div>
                        </form>
                    </div>	
                    <div class="col-md-6 login-left">
                        <h4>NEW CUSTOMERS</h4>
                        <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                        <a class="acount-btn" href="register.php">Create an Account</a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
         
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>