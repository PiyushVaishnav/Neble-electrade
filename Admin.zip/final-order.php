<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());



if(isset($_SESSION['cart']) )
{
    if(isset($_SESSION['User_id']))
    {

        //Order Master Place Query 
        
        $date = date("d-m-y");
        $q = mysql_query("insert into order_master (Order_date,User_id) values ('$date','{$_SESSION['User_id']}') ") or die(mysql_error());
        
        $orderid  = mysql_insert_id();
        
        
        foreach ($_SESSION['cart'] as $key => $value) {

            //Order Details
            $productq  = mysql_query("select * from  product where Product_id = '{$value}'") or die(mysql_error());
            $pdata = mysql_fetch_row($productq);
        
            mysql_query("insert order_details (Order_id,Product_id,Quantity,Amount) values ('{$orderid}','{$value}','1','{$pdata[4]}') ") or die(mysql_error());
            
            
            
        echo "<script>alert('Order Placed');window.location='index.php';</script>";
            
        }
        
        //Delete Session
            unset($_SESSION['cart']);
            unset($_SESSION['counter']);
            

    }  else {
    
        echo "<script>alert('Login Required');window.location='index.php';</script>";
    }
    
}else
{
    echo "<script>alert('No Product in Cart');window.location='index.php';</script>";
}