<?php
mysql_connect("localhost", "root", "") or die("conn is error".mysql_error());
mysql_select_db("nobleelectrade") or die("selection is error".mysql_error());
?>

<div class="header">
            <div class="header-top">
                <div class="container">
                    <div class="col-sm-4 logo">
                        <a href="index.php"><img src="images/NElogo.png"style="width:100px;" alt=""></a>	    
                    </div>
                    <div class="col-sm-4 logo">
                        <a href="index.php"><img src="images/Untitled-3.png" alt=""></a>	
                    </div>

                    <div class="col-sm-4 header-left">		
                        <p class="log">
                            
                             <?php
                        if(isset($_SESSION['User_id']))
                         
                            {
                                
                                echo "<a href='view-order.php'>view order</a>";
                                echo "<a href='changepassword.php'>change password</a>";
                                echo "<a href='logout.php'>Logout</a>";
                            }else
                            {
                                echo "<a href='login.php'>Login</a>";
                                
                            }
                                
                                ?>
                            
                            
                        <div class="cart box_1">
                           
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="container">
                <div class="head-top">
                    <div class="col-sm-2 number">
                        <span><i class="glyphicon glyphicon-phone"></i>096 6261 0717</span>
                    </div>
                    <div class="col-sm-8 h_menu4">
                        <ul class="memenu skyblue">
                            <li class=" grid"><a  href="index.php">Home</a></li>	
                            <li class=" grid"><a  href="aboutas.php">About us</a></li>	
                          
                            <li class="grid"><a>Category</a>
                                <div class="mepanel">
                                    
                                        <div class="col1">
                                            <div class="h_nav">
                                                <h4>All Product</h4>
                                                <ul>
                                                     <?php
                                                  $selectq = mysql_query("select *from category ") or die(mysql_error());                     
                                                    //echo "<select name='txtcatid'>";

                                                    while ($data = mysql_fetch_row($selectq)) 
                                                            {
                                                               echo "<li><a href='index.php?cid=$data[0]' value='{$data[0]}'>$data[1]</a></li>";
                                                            }

                                                    //echo "</select>";
                                                  ?>     

                                                </ul>	
                                            </div>							
                                        </div>
                                        
                                </div>
                            </li>
                           				
                            <li><a class="color6" href="contact.php">Contact us</a></li>
                            <li><a class="color6" href="feedback.php">Feedback</a></li>
                        </ul> 
                    </div>
                    <div class="col-sm-2 search">		
                        <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i> </a>
                    </div>
                    <div class="clearfix"> </div>
                    <!---pop-up-box---->
                    <script type="text/javascript" src="js/modernizr.custom.min.js"></script>    
                    <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
                    <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
                    <!---//pop-up-box---->
                    <div id="small-dialog" class="mfp-hide">
                        <div class="search-top">
                            <div class="login">
                                <input type="submit" value="">
                                <input type="text" value="Type something..." onfocus="this.value = '';" onblur="if (this.value == '') {
                                                                    this.value = '';
                                                                }">		
                            </div>
                            <p></p>
                        </div>				
                    </div>
                    <script>
                        $(document).ready(function () {
                            $('.popup-with-zoom-anim').magnificPopup({
                                type: 'inline',
                                fixedContentPos: false,
                                fixedBgPos: true,
                                overflowY: 'auto',
                                closeBtnInside: true,
                                preloader: false,
                                midClick: true,
                                removalDelay: 300,
                                mainClass: 'my-mfp-zoom-in'
                            });

                        });
                    </script>			
                    <!---->		
                </div>
            </div>
        </div>