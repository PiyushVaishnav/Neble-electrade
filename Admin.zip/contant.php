 <div class="content">
            <div class="container">
                <div class="content-top">
                    <h1>Recent Products</h1>
                    <div class="content-top1">
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi.png" alt="" />
                                </a>
                                <h3><a href="single.html">Tops</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi2.png" alt="" />
                                </a>
                                <h3><a href="single.html">T-Shirt</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi4.png" alt="" />
                                </a>
                                <h3><a href="single.html">Shirt</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi1.png" alt="" />
                                </a>
                                <h3><a href="single.html">Tops</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="clearfix"> </div>
                    </div>	
                    <div class="content-top1">
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi3.png" alt="" />
                                </a>
                                <h3><a href="single.html">Shirt</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi5.png" alt="" />
                                </a>
                                <h3><a href="single.html">T-Shirt</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi6.png" alt="" />
                                </a>
                                <h3><a href="single.html">Jeans</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi7.png" alt="" />
                                </a>
                                <h3><a href="single.html">Tops</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>

                            </div>
                        </div>	
                        <div class="clearfix"> </div>
                    </div>	
                </div>
            </div>
        </div>