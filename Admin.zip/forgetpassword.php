<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
if($_POST)
{
    $Email_id = $_POST['Email'];
    
    $q = mysql_query("select * from user where Email='{$Email_id}'") or die(mysql_error());
    
    $data = mysql_fetch_row($q);
    
    if($data>0)
    {
            require './PHPMailerAutoload.php';


            $mail = new PHPMailer;

            $mail->isSMTP();                                // Set mailer to use SMTP
                                                 
            
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->Port = 587;                                    // TCP port to connect to
            $mail->Username = 'nobleelectrade1@gmail.com';                 // SMTP username
            $mail->Password = 'noble@123';                           // SMTP password
            
            $mail->addReplyTo('nobleelectrade1@gmail.com', 'nobleelectrade');
            
            $mail->setFrom('nobleelectrade1@gmail.com', 'nobleelectrade');
            
            $mail->addReplyTo('nobleelectrade1@gmail.com', 'nobleelectrade');
            
            $address = $data[2];
            $mail->addAddress($address, 'nobleelectrade');     // Add a recipient

            
            $mail->isHTML(true);                                  // Set email format to HTML

            $mail->Subject = "Forgot Password" ;
            $body = "Hello...<br> Your Password is $data[3] For nobleelectrade Website";
            $mail->msgHTML($body);
            

            if(!$mail->send()) {
                echo "<script> alert ('Password could not be sent.');</script>";
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            } else {
                echo "<script> alert ('Your Password sent on your Email ID.');window.location='index.php';</script>";
            }
    }
    else
    {
        echo "<script>alert('Email-Id is not found in our Database');</script>";
    }
}




?>

<html>
    <head>
       <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
      
        <!--content-->
       
        
        
        <div class="account">
            <div class="container">
                <h1>Forget Password</h1>
                <div class="account_grid">
                    <div class="col-md-6 login-right">
                        <form method="Post">
                            <span>Email Address</span>
                            <input type="text" name="Email"> 

                                                <div c  lass="word-in">
                                <input type="submit" value="Send">
                            </div>
                        </form>
                    </div>	
                    <div class="col-md-6 login-left">
                        <h4>NEW CUSTOMERS</h4>
                        <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                        <a class="acount-btn" href="register.php">Create an Account</a>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>