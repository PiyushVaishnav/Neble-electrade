  <div class="banner">
            <div class="col-sm-3 banner-mat">
                <img class="img-responsive"	src="images/11.jpg" alt="">
            </div>
            <div class="col-sm-6 matter-banner">
                <div class="slider">
                    <div class="callbacks_container">
                        <ul class="rslides" id="slider">
                            <li>
                                <img src="images/p3.png" alt="">
                            </li>
                            <li>
                                <img src="images/p4.png" alt="">   
                            </li>
                            <li>
                                <img src="images/6.png" alt="">
                            </li>
                            <li>
                                <img src="images/5.png" alt="">
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 banner-mat">
                <img class="img-responsive" src="images/22.jpg" alt="">
            </div>
            <div class="clearfix"> </div>
        </div>