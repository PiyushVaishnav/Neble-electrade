<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
  if ($_POST) {
     $User_id=$_POST['txtname'];
     $Date = $_POST['txtdate'];
      $Details = $_POST['txtcomm'];
    $q = mysql_query("insert into feedback(User_id,Date,Details)values('{$User_id}','{$Date}','{$Details}')") or die(mysql_error());

    if ($q) {

        echo"<script> alert('Record Inserted');</script>";
    }
}


?>

<html>
    <head>
        <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
                $(".memenu").memenu();
            });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
            $(function () {
                $("#slider").responsiveSlides({
                    auto: true,
                    speed: 500,
                    namespace: "callbacks",
                    pager: true,
                });
            });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
        <!--content-->

        <div class="contact">
            <div class="container">
                <h1>Feedback</h1>
                 <div class="contact-bottom-top">
                               
                <p>Please provide your feedback below:</p>
                 </div>
                <div class="contact-grids">
                    <div class="contact-form">
                        <form method="post">
                           
                            <div class="contact-bottom-top">
                                <span>Comments:</span>
                                <textarea name="txtcomm" > </textarea>								
                            </div>
                             
                            <div class=" col-md-6 register-bottom-grid">
                                <div class="mation">
                                    <span>Name</span>
                                    <input type="text" name="txtname" required="true">
                                </div>
                            </div>
                            <div class=" col-md-6 register-bottom-grid">
                                <div class="mation">
                                    <span>Date</span>
                                    <input type="text" name="txtdate" required="true">
                                </div>
                            </div>		
                            <input type="submit" value="Post">
                        </form>
                    </div>
                    <div class="address">
                        <div class=" address-more">
                            <h2>Address</h2>
                            <div class="col-md-4 address-grid">
                                <i class="glyphicon glyphicon-map-marker"></i>
                                <div class="address1">
                                    <p>Rajkot-360001</p>
                                    <p>Gujarat, India</p>
                                    
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="col-md-4 address-grid ">
                                <i class="glyphicon glyphicon-phone"></i>
                                <div class="address1">
                                    <p>+0281 2464749</p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="col-md-4 address-grid ">
                                <i class="glyphicon glyphicon-envelope"></i>
                                <div class="address1">
                                    <p>nobleelectrade1</p>
                                    <p>@Gmail.com</p>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>







        <!--//content-->
        <!--footer-->
        <?php
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>