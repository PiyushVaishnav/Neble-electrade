<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
?>

<html>
    <head>
        <title>Noble Eleatic</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
       
        <div class="header">
            <div class="header-top">
                <div class="container">
                    <div class="col-sm-4 world">
                        </div>
                    <div class="col-sm-4 logo">
                        <a href=""><img src="images/Untitled-3.png" alt=""></a>	
                    </div>

                    <div class="col-sm-4 header-left">		
                        <p class="log"><a  href="index.php" >Logout</a>
                            <a  href="changepassword.php"  >Change Password</a>
                           
                        <div class="cart box_1">
                           

                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="container">
                <div class="head-top">
                    <div class="col-sm-2 number">
                        <span><i class="glyphicon glyphicon-phone"></i>096 6261 0717</span>
                    </div>
                    <div class="col-sm-8 h_menu4">
                        <ul class="memenu skyblue">
                            <li class=" grid"><a  href="index.php">Home</a></li>	
                            <li class=" grid"><a  href="aboutas.php">About us</a></li>	
                           
                            <li><a  href="#">Category</a>
                                <div class="mepanel">
                                    <div class="row">
                                        <div class="col1">
                                            <div class="h_nav">
                                                <h4>All Product</h4>
                                               
                                            
                                             <ul>
                                                     <?php
                                                  $selectq = mysql_query("select *from category ") or die(mysql_error());                     
                                                    //echo "<select name='txtcatid'>";

                                                    while ($data = mysql_fetch_row($selectq)) 
                                                            {
                                                               echo "<li><a href='index.php?cid=$data[0]' value='{$data[0]}'>$data[1]</a></li>";
                                                            }

                                                    //echo "</select>";
                                                  ?>     

                                                </ul>	

                                            
                                            </div>							
                                        </div>
                                        
                                    </div>
                                </div>
                            </li>
                            
                            <li><a class="color6" href="contact.php">Contact</a></li>
                        </ul> 
                    </div>
                    <div class="col-sm-2 search">		
                        <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i> </a>
                    </div>
                    <div class="clearfix"> </div>
                    <!---pop-up-box---->
                    <script type="text/javascript" src="js/modernizr.custom.min.js"></script>    
                    <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
                    <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
                    <!---//pop-up-box---->
                    <div id="small-dialog" class="mfp-hide">
                        <div class="search-top">
                            <div class="login">
                                <input type="submit" value="">
                                <input type="text" value="Type something..." onfocus="this.value = '';" onblur="if (this.value == '') {
                                                                    this.value = '';
                                                                }">		
                            </div>
                            <p>	Shopping</p>
                        </div>				
                    </div>
                    <script>
                        $(document).ready(function () {
                            $('.popup-with-zoom-anim').magnificPopup({
                                type: 'inline',
                                fixedContentPos: false,
                                fixedBgPos: true,
                                overflowY: 'auto',
                                closeBtnInside: true,
                                preloader: false,
                                midClick: true,
                                removalDelay: 300,
                                mainClass: 'my-mfp-zoom-in'
                            });

                        });
                    </script>			
                    <!---->		
                </div>
            </div>
        </div>
        
        
       
        <!--content-->
       
        
        
     <div class="container">
	<div class="check-out">
		<h1>Order View</h1>
                <?php
                $q = mysql_query("SELECT * from order_master where User_id = '{$_SESSION['User_id']}'  ") or die(mysql_error());

                   echo " <table>";
		  echo"<tr>";
                 
                  echo"<th>Order ID</th>";
			echo"<th>Order Date</th>";		
			echo"<th>User ID </th>";
                  
                        echo"</tr>";
                  
                  
                  
                  while($data = mysql_fetch_row($q))
                  {
                      echo "<tr>";
                      
                      echo "<td>$data[0]</td>";
                      echo "<td>$data[1]</td>";
                      echo "<td>$data[2]</td>";

                      
                        $tq = mysql_query(" SELECT
    `product`.`Name`
    , `order_details`.`Quantity`
    , `order_details`.`Amount`
    , `order_details`.`Order_id`
FROM
    `product`
    INNER JOIN `order_details` 
        ON (`product`.`Product_id` = `order_details`.`Product_id`) WHERE  
     `order_details`.`Order_id` = '{$data[0]}'  ") or die(mysql_error());

                        
                        
                        echo "<tr><td><table>";
                        
                        
                        while($tdata  = mysql_fetch_row($tq))
                        {
                            echo "<tr>";
                            echo "<td>Name : $tdata[0]</td>";
                            echo "<td>Qty : $tdata[1]</td>";
                            echo "<td>Amount : $tdata[2]</td>";
                            echo "<tr>";
                            
                        }
                        
                        echo "</td></tr></table>";
                        
                        
                      
                        
                      echo  "</td>";
                      
                      echo "</tr>";
                  }
                  
                  
                echo"</table>";
	?>
               
        
        
	<div class="clearfix"> </div>
    </div>
</div>     
        
        
        
        
        
        
        
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>