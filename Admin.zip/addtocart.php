<?php

session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
$pid = $_GET['pid'];


$cart = array();

if(isset($_SESSION['cart']))
{
    
    $counter = $_SESSION['counter'] +1 ;

    $_SESSION['counter'] = $counter ;
    
    $_SESSION['cart'][$counter] = $pid;
    
    
    
}else
{
    
    
    $_SESSION['cart'][0] = $pid;
    
    $_SESSION['counter'] = 0;
    
    
}


header("location:checkout.php");