<?php
session_start();
mysql_connect("localhost", "root", "") or die("conn is error".mysql_error());
mysql_select_db("nobleelectrade") or die("selection is error".mysql_error());
?>
<html>
    <head>
        
        <title>Noble Electrade</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Custom Theme files -->
        <!--theme-style-->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
        <!--//theme-style-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!-- start menu -->
        <link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
        <script type="text/javascript" src="js/memenu.js"></script>
        <script>$(document).ready(function () {
        $(".memenu").memenu();
    });</script>
        <script src="js/simpleCart.min.js"></script>
        <!-- slide -->
        <script src="js/responsiveslides.min.js"></script>
        <script>
         $(function () {
             $("#slider").responsiveSlides({
                 auto: true,
                 speed: 500,
                 namespace: "callbacks",
                 pager: true,
             });
         });
        </script>
    </head>
    <body>
        <!--header-->
        <?php
        include './header.php';
        ?>
        <!--banner-->
      <?php
      include './banner.php';
      ?>
        <!--//banner-->
        <!--content-->
       
        
          <div class="content">
            <div class="container">
                <div class="content-top">
                    <h1>Products</h1>
                    <div class="content-top1">
                        
                        
                        <?php 
                        if(isset($_GET['cid']))
                        {
                            
                            $cid = $_GET['cid'];
                        $q= mysql_query("select * from product where Cat_id ='{$cid}'") or die(mysql_error());
                            
                        }else
                        {
                        $q= mysql_query("select * from product Limit 0,8") or die(mysql_error());
                            
                        }
                        
                        
                        while($data = mysql_fetch_row($q))
                        {
                            
                            echo " 
                        <div class='col-md-3 col-md2'>
                            <div class='col-md1 simpleCart_shelfItem'>
                                <a href='productdetails.php?pid=$data[0]'>
                                    <img class='img-responsive' src='images/$data[5]' alt='' />
                                </a>
                                <h3><a href='productdetails.php?pid=$data[0]'>$data[1]</a></h3>
                                <div class='price'>
                                    <h5 class='item_price'>Rs $data[4]</h5>
                                    <a href='productdetails.php?pid=$data[0]' class='item_add'>More Detail</a>
                                    <div class='clearfix'> </div>
                                </div>
                            </div>
                        </div>	
                       
                        
                        ";
                            
                            
                        }
                        
                        
                        
                        
                        ?>
                        
<!--                        <div class="col-md-3 col-md2">
                            <div class="col-md1 simpleCart_shelfItem">
                                <a href="single.html">
                                    <img class="img-responsive" src="images/pi.png" alt="" />
                                </a>
                                <h3><a href="single.html">Tops</a></h3>
                                <div class="price">
                                    <h5 class="item_price">$300</h5>
                                    <a href="#" class="item_add">Add To Cart</a>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>	-->
                       
                        
                        
                        
                        <div class="clearfix"> </div>
                    </div>	
                  
                </div>
            </div>
        </div>
        
        <!--//content-->
        <!--footer-->
        <?php  
        include './footer.php';
        ?>

        <!--//footer-->
    </body>
</html>