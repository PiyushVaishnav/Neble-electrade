<?php
session_start();
mysql_connect("localhost", "root", "") or die("connnction is error" . mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection" . mysql_error());
?>

<html>
    <head>
                <title>Industrial Electrical Products  </title>

    </head>
    <body>
    <center> <a href="index.php"><img src="images/Untitled-3.png" alt=""></a>	
    </center> 
    <hr>
    Date <?php    echo date('d-m-y');?>
    <input type="button" value="print" onclick="window.print();">  
    <br>
    
             <center>                                                                    
<?php
mysql_connect("localhost", "root", "") or die("connnction is error".  mysql_error());
mysql_select_db("nobleelectrade") or die("error is selection". mysql_error());
$q = mysql_query("SELECT
    `product`.`Product_id`
    , `product`.`Name`
    , `product`.`Details`
    , `category`.`Cat_name`
    , `product`.`Price`
    , `product`.`Image`
FROM
    `nobleelectrade`.`category`
    INNER JOIN `nobleelectrade`.`product` 
        ON (`category`.`Cat_id` = `product`.`Cat_id`);") or die(mysql_error());
echo "<table border='1'  align ='center' >";
echo "<thead>";
 echo"<tr>";
echo"<th>Product Id</th>";
echo"<th>Name</th>";
echo"<th>Details</th>";
echo"<th>Category</th>";
echo"<th>Price</th>";
echo "<th>Image</th>";
echo"</tr>";
echo "</thead>";                                                                
echo "<tbody>";
echo "</tr>";
while ($data = mysql_fetch_row($q)) {
    echo "<tr>";
    echo "<td>$data[0]</td><td>$data[1]</td><td>$data[2]</td><td>$data[3]</td><td>$data[4]</td><td><img src='../images/$data[5]' style='width:100px;'></td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";                                                                     

?>
         </center>
</body>
</html>
