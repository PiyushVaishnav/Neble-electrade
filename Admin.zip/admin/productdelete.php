<?php
session_start();
mysql_connect("localhost", "root", "") or die("conn is error".mysql_error());
mysql_select_db("nobleelectrade") or die("selection is error".mysql_error());

if(isset($_GET['data']))
{
   $data = $_GET['data'];
$q = mysql_query("delete from product where Product_id='{$data}'") or die("qur is error".mysql_error());

echo "<script>alert('record deleted');window.location='producttable.php';</script>";

}