<div class="w3_agileits_top_nav">
    <ul id="gn-menu" class="gn-menu-main">
        <!-- /nav_agile_w3l -->
        <li class="gn-trigger">
            <a class="gn-icon gn-icon-menu"><i class="fa fa-bars" aria-hidden="true"></i><span>Menu</span></a>
            <nav class="gn-menu-wrapper">
                <div class="gn-scroller scrollbar1">
                    <ul class="gn-menu agile_menu_drop">
                        <li><a href="mainpage.php"> <i class="fa fa-tachometer"></i> Home</a></li>
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>Forms <i class="fa fa-angle-down" aria-hidden="true"></i> 
                        <ul class="gn-submenu">
                            <li class="mini_list_w3"><a href="cataegorysfrom.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Category</a></li>
                            <li class="mini_list_agile"><a href="productfrom.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Product</a></li>
                            <li class="mini_list_w3"><a href="ordermasterform.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Order Master</a></li>
                            <li class="mini_list_agile"><a href="orderdetail.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Order Details</a></li>
                            <li class="mini_list_w3"><a href="userform.php"><i class="fa fa-caret-right" aria-hidden="true"></i> User</a></li>
                            <li class="mini_list_agile"><a href="paymentform.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Payment</a></li>
                            <li class="mini_list_w3"><a href="feedbackform.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Feedback</a></li>

                        </ul>
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>Table <i class="fa fa-angle-down" aria-hidden="true"></i> 
                        <ul class="gn-submenu">
                            <li class="mini_list_w3"><a href="catagorytable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Category Table</a></li>
                            <li class="mini_list_agile"><a href="producttable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Product Table</a></li>
                            <li class="mini_list_w3"><a href="ordermastertable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Order Master Table</a></li>
                            <li class="mini_list_agile"><a href="orderdetailtable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Order Details Table</a></li>
                            <li class="mini_list_w3"><a href="usertable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> User Table</a></li>
                            <li class="mini_list_agile"><a href="paymenttable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Payment Table</a></li>
                            <li class="mini_list_w3"><a href="feedbacktable.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Feedback Table</a></li>

                        </ul>
                    </ul>
                </div><!-- /gn-scroller -->
            </nav>
        </li>
        <!-- //nav_agile_w3l -->
        <li class="second logo"><h1><a href="main-page.html"><i class="fa fa-graduation-cap" aria-hidden="true"></i>Industrial Electrical Products  </a></h1></li>
        <li class="second admin-pic">
            <ul class="top_dp_agile">
                <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <div>	
                            <span><img src="images/123q.jpg"style="width:50px;"style="height: 50px;" alt=""> </span> 
                        </div>	
                    </a>
                    <ul class="dropdown-menu drp-mnu">
                        <li> <a href="changepassword.php"><i class="fa fa-user"></i>Password</a> </li> 
                        <li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                    </ul>
                </li>

            </ul>
        </li>


        <li class="second w3l_search admin_login">

<!--            <form action="#" method="post">
                <input type="search" name="search" placeholder="Search here..." required="">
                <button class="btn btn-default" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
-->
        </li>


    </ul>
    <!-- //nav -->

</div>